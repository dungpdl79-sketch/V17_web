-- ============================================================================
-- Bản vá CSDL V17 — chạy MỘT LẦN trên D1 đang có dữ liệu.
--   npx wrangler d1 execute dinhcaotritue-db --remote --file=drizzle/0001_v17_security.sql
-- Thử trước ở local:
--   npx wrangler d1 execute dinhcaotritue-db --local --file=drizzle/0001_v17_security.sql
-- ============================================================================

ALTER TABLE `users` ADD COLUMN `password_hash` text;
--> statement-breakpoint
ALTER TABLE `users` ADD COLUMN `password_salt` text;
--> statement-breakpoint

CREATE TABLE IF NOT EXISTS `sessions` (
	`id` text PRIMARY KEY NOT NULL,
	`email` text NOT NULL,
	`created_at` text NOT NULL,
	`expires_at` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS `sessions_email_idx` ON `sessions` (`email`);
--> statement-breakpoint

CREATE TABLE IF NOT EXISTS `exam_starts` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`exam_id` integer NOT NULL,
	`student_email` text NOT NULL,
	`started_at` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX IF NOT EXISTS `exam_start_unique` ON `exam_starts` (`exam_id`,`student_email`);
--> statement-breakpoint

ALTER TABLE `exams` ADD COLUMN `scoring` text DEFAULT '{}' NOT NULL;
--> statement-breakpoint

ALTER TABLE `attempts` ADD COLUMN `points` real DEFAULT 0 NOT NULL;
--> statement-breakpoint
ALTER TABLE `attempts` ADD COLUMN `max_points` real DEFAULT 0 NOT NULL;
--> statement-breakpoint

-- Đề cũ có thể đang chứa đáp án Đúng/Sai trong public_questions.
-- Đóng chúng lại để buộc phát lại bằng bản vá (an toàn hơn là vá dữ liệu tại chỗ).
UPDATE `exams` SET `status` = 'closed' WHERE `status` = 'open';
