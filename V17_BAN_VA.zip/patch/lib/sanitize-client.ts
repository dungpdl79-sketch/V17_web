/* ============================================================================
   Bộ lọc HTML — chuyển nguyên vẹn từ V15 sang V17.
   Câu hỏi được phép chứa HTML (bảng biến thiên, bảng xét dấu, ảnh nhúng)
   nên không thể escape toàn bộ; ta giữ whitelist và bỏ mọi thứ còn lại.
   Chạy phía trình duyệt vì cần DOMParser.
   ========================================================================== */

const OK_TAGS = new Set([
  "B","I","U","EM","STRONG","SUP","SUB","BR","P","DIV","SPAN","SMALL",
  "UL","OL","LI","TABLE","THEAD","TBODY","TFOOT","TR","TD","TH","IMG",
  "HR","CENTER","FONT","CODE","PRE",
]);
const OK_ATTR = new Set([
  "style","colspan","rowspan","align","valign","width","height","class","color","size",
]);
const DROP_WHOLE = new Set([
  "SCRIPT","STYLE","IFRAME","OBJECT","EMBED","LINK","META","FORM","INPUT",
  "BUTTON","SVG","MATH","BASE","TEMPLATE","AUDIO","VIDEO","SOURCE",
]);

export function sanitize(html: unknown): string {
  if (typeof window === "undefined" || typeof DOMParser === "undefined") return "";
  const doc = new DOMParser().parseFromString(String(html ?? ""), "text/html");
  doc.body.querySelectorAll("*").forEach((el) => {
    const tag = el.tagName.toUpperCase();
    if (DROP_WHOLE.has(tag)) {
      el.remove();
      return;
    }
    if (!OK_TAGS.has(tag)) {
      el.replaceWith(...el.childNodes);
      return;
    }
    [...el.attributes].forEach((a) => {
      const n = a.name.toLowerCase();
      const v = a.value;
      if (n === "src" && tag === "IMG") {
        if (!/^data:image\/(png|jpeg|jpg|gif|webp);base64,/i.test(v.trim()))
          el.removeAttribute("src");
        return;
      }
      if (!OK_ATTR.has(n)) {
        el.removeAttribute(a.name);
        return;
      }
      if (/javascript:|expression\s*\(|url\s*\(|@import|behavior\s*:/i.test(v))
        el.removeAttribute(a.name);
    });
  });
  return doc.body.innerHTML;
}
