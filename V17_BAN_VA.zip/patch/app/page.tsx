import { cookies } from "next/headers";
import Dashboard from "./v17-dashboard";
import LoginCard from "./components/login-card";
import { SESSION_COOKIE, getUserByToken } from "@/lib/auth";

export const dynamic = "force-dynamic";

export default async function Home() {
  const cookieStore = await cookies();
  const token = cookieStore.get(SESSION_COOKIE)?.value ?? null;

  // Phiên được xác thực với CSDL — không còn tin vào nội dung cookie như bản cũ.
  const user = await getUserByToken(token).catch(() => null);

  if (!user) return <LoginCard />;
  return <Dashboard initialUser={user} />;
}
