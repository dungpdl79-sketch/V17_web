import { eq } from "drizzle-orm";
import { getDb } from "@/db";
import { auditLogs, users } from "@/db/schema";
import {
  clearCookieHeader,
  createSession,
  destroySession,
  hashPassword,
  readTokenFromCookieHeader,
  sessionCookieHeader,
  verifyPassword,
} from "@/lib/auth";
import {
  LEGACY_ACTIVATION_CODE,
  TEACHER_SIGNUP_CODE,
  isTeacherEmail,
} from "@/lib/config";

const now = () => new Date().toISOString();
const clean = (v: unknown, n = 120) =>
  String(v ?? "").replace(/[<>]/g, "").trim().slice(0, n);

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

function fail(msg: string, status = 400) {
  return Response.json({ error: msg }, { status });
}

async function log(
  actorEmail: string,
  action: string,
  entityId: string,
  details: string
) {
  try {
    await getDb().insert(auditLogs).values({
      actorEmail,
      action,
      entityType: "auth",
      entityId,
      details,
      createdAt: now(),
    });
  } catch {
    /* nhật ký không được phép làm hỏng đăng nhập */
  }
}

export async function POST(req: Request) {
  try {
    const b = (await req.json()) as Record<string, unknown>;
    const mode = clean(b.mode, 12);

    /* ---------------- ĐĂNG XUẤT (sửa lỗi nút đăng xuất hỏng) -------------- */
    if (mode === "logout") {
      const token = readTokenFromCookieHeader(req.headers.get("cookie"));
      await destroySession(token);
      return new Response(JSON.stringify({ ok: true }), {
        headers: {
          "content-type": "application/json",
          "set-cookie": clearCookieHeader,
        },
      });
    }

    const email = clean(b.email, 120).toLowerCase();
    const password = String(b.password ?? "");

    if (!EMAIL_RE.test(email)) return fail("Email không hợp lệ.");
    if (password.length < 8)
      return fail("Mật khẩu phải có ít nhất 8 ký tự.");

    const db = getDb();
    const [existing] = await db
      .select()
      .from(users)
      .where(eq(users.email, email))
      .limit(1);

    /* ---------------- ĐĂNG NHẬP ------------------------------------------- */
    if (mode === "login") {
      if (!existing || !existing.passwordHash) {
        // Không tiết lộ email nào đã tồn tại.
        return fail("Email hoặc mật khẩu không đúng.", 401);
      }
      const ok = await verifyPassword(
        password,
        existing.passwordSalt,
        existing.passwordHash
      );
      if (!ok) {
        await log(email, "login_failed", email, "sai mật khẩu");
        return fail("Email hoặc mật khẩu không đúng.", 401);
      }
      const { token } = await createSession(email);
      await log(email, "login", email, existing.role);
      return new Response(JSON.stringify({ ok: true }), {
        headers: {
          "content-type": "application/json",
          "set-cookie": sessionCookieHeader(token),
        },
      });
    }

    /* ---------------- ĐĂNG KÝ / KÍCH HOẠT --------------------------------- */
    if (mode === "register") {
      const name = clean(b.name, 100);
      const code = clean(b.code, 64);
      if (name.length < 2) return fail("Hãy nhập họ và tên.");

      const wantsTeacher = isTeacherEmail(email);
      if (wantsTeacher && code !== TEACHER_SIGNUP_CODE)
        return fail("Email này cần MÃ GIÁO VIÊN để đăng ký.", 403);

      // Tài khoản cũ (từ bản V17 trước, chưa có mật khẩu) => kích hoạt.
      if (existing) {
        if (existing.passwordHash)
          return fail("Email đã được đăng ký. Hãy chọn Đăng nhập.", 409);
        if (!wantsTeacher && code !== LEGACY_ACTIVATION_CODE)
          return fail(
            "Tài khoản đã tồn tại từ trước. Cần MÃ KÍCH HOẠT do giáo viên cung cấp.",
            403
          );
        const { salt, hash } = await hashPassword(password);
        await db
          .update(users)
          .set({ name, passwordHash: hash, passwordSalt: salt })
          .where(eq(users.email, email));
        const { token } = await createSession(email);
        await log(email, "activate", email, existing.role);
        return new Response(JSON.stringify({ ok: true }), {
          headers: {
            "content-type": "application/json",
            "set-cookie": sessionCookieHeader(token),
          },
        });
      }

      // Tài khoản mới. VAI TRÒ DO MÁY CHỦ QUYẾT ĐỊNH — không nhận từ client.
      const role: "teacher" | "student" = wantsTeacher ? "teacher" : "student";
      const { salt, hash } = await hashPassword(password);
      await db.insert(users).values({
        email,
        name,
        role,
        passwordHash: hash,
        passwordSalt: salt,
        createdAt: now(),
      });
      const { token } = await createSession(email);
      await log(email, "register", email, role);
      return new Response(JSON.stringify({ ok: true }), {
        headers: {
          "content-type": "application/json",
          "set-cookie": sessionCookieHeader(token),
        },
      });
    }

    return fail("Thao tác không hợp lệ.");
  } catch (e) {
    return Response.json(
      { error: e instanceof Error ? e.message : "Lỗi máy chủ" },
      { status: 500 }
    );
  }
}
