import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Đỉnh Cao Trí Tuệ V17",
  description:
    "Hệ thống quản lý lớp học, ngân hàng câu hỏi và kiểm tra Toán 12 nhiều thiết bị.",
  icons: { icon: "/favicon.svg", shortcut: "/favicon.svg" },
};

/* ---------------------------------------------------------------------------
   MathJax — sửa lỗi V17 không hiển thị được công thức.
   startup.typeset = false: ta tự gọi typesetPromise sau mỗi lần render React.

   ⚠️ KHUYẾN NGHỊ DÙNG BẢN CỤC BỘ (phòng máy mất mạng vẫn chạy):
      1. Tải https://cdn.jsdelivr.net/npm/mathjax@3.2.2/es5/tex-mml-chtml.js
      2. Lưu vào  public/mathjax/tex-mml-chtml.js
      3. Đổi src bên dưới thành "/mathjax/tex-mml-chtml.js" và bỏ crossOrigin.
   Nếu vẫn dùng CDN, hãy lấy chuỗi sha384 trên trang jsDelivr của đúng file này
   và thêm  integrity="sha384-..."  để chống CDN bị thay nội dung.
   ------------------------------------------------------------------------- */
const MATHJAX_CONFIG = `window.MathJax={
  tex:{inlineMath:[['$','$'],['\\\\(','\\\\)']],displayMath:[['$$','$$'],['\\\\[','\\\\]']]},
  options:{skipHtmlTags:['script','noscript','style','textarea','pre']},
  startup:{typeset:false}
};`;

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="vi">
      <head>
        <script dangerouslySetInnerHTML={{ __html: MATHJAX_CONFIG }} />
        <script
          id="MathJax-script"
          async
          crossOrigin="anonymous"
          src="https://cdn.jsdelivr.net/npm/mathjax@3.2.2/es5/tex-mml-chtml.js"
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
