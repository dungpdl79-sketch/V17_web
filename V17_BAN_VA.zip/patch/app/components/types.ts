import type { Scoring } from "@/lib/grading";
import type { PublicQuestion } from "@/lib/import-v15";

export type Role = "teacher" | "student";

export type UserInfo = { email: string; name: string; role: Role };

export type ClassRow = {
  id: number;
  name: string;
  code: string;
  schoolYear: string;
  students?: number;
};

export type ExamRow = {
  id: number;
  classId: number;
  title: string;
  code: string;
  durationMinutes: number;
  status: "draft" | "open" | "closed";
  scoring: Scoring;
  publicQuestions: PublicQuestion[];
  createdAt: string;
};

export type AttemptRow = {
  id: number;
  examId: number;
  studentEmail: string;
  studentName: string;
  score: number;
  maxScore: number;
  points: number;
  maxPoints: number;
  startedAt: string;
  submittedAt: string;
};

export type StartRow = { examId: number; startedAt: string };

export type Data = {
  user: UserInfo;
  classes: ClassRow[];
  exams: ExamRow[];
  attempts: AttemptRow[];
  examStarts: StartRow[];
};

export type Act = (payload: Record<string, unknown>) => Promise<unknown>;

/** Câu trả lời của một bài: mcq/sa là chuỗi, tf là mảng "T" | "F" | "" */
export type ExamAnswers = Record<string, string | string[]>;
