"use client";
import { useState } from "react";

export default function LoginCard() {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  const submit = async () => {
    setBusy(true);
    setErr("");
    try {
      const r = await fetch("/api/auth", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ mode, email, name, password, code }),
      });
      const j = await r.json();
      if (r.ok) window.location.reload();
      else setErr(j.error || "Không đăng nhập được.");
    } catch {
      setErr("Không kết nối được máy chủ.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <main className="signin">
      <div className="signin-card">
        <div className="brand-mark">Đ</div>
        <p className="eyebrow">ĐỈNH CAO TRÍ TUỆ</p>
        <h1>V17 · Lớp học số</h1>
        <p>
          {mode === "login"
            ? "Đăng nhập bằng email và mật khẩu của em/thầy cô."
            : "Tạo tài khoản mới. Vai trò do hệ thống tự xác định theo email."}
        </p>

        <div className="auth-tabs">
          <button
            className={mode === "login" ? "on" : ""}
            onClick={() => {
              setMode("login");
              setErr("");
            }}
          >
            Đăng nhập
          </button>
          <button
            className={mode === "register" ? "on" : ""}
            onClick={() => {
              setMode("register");
              setErr("");
            }}
          >
            Đăng ký
          </button>
        </div>

        <div className="auth-form">
          <input
            type="email"
            autoComplete="username"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          {mode === "register" && (
            <input
              type="text"
              autoComplete="name"
              placeholder="Họ và tên"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          )}
          <input
            type="password"
            autoComplete={mode === "login" ? "current-password" : "new-password"}
            placeholder="Mật khẩu (tối thiểu 8 ký tự)"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !busy) submit();
            }}
          />
          {mode === "register" && (
            <input
              type="text"
              placeholder="Mã giáo viên / mã kích hoạt (nếu được yêu cầu)"
              value={code}
              onChange={(e) => setCode(e.target.value)}
            />
          )}

          {err && <div className="auth-error">{err}</div>}

          <button className="primary-btn" disabled={busy} onClick={submit}>
            {busy
              ? "Đang xử lý…"
              : mode === "login"
                ? "Đăng nhập"
                : "Tạo tài khoản"}
          </button>
        </div>

        <div className="trust-row">
          <span>✓ Mật khẩu mã hoá</span>
          <span>✓ Phiên có hạn</span>
          <span>✓ Đáp án giữ ở máy chủ</span>
        </div>
      </div>
    </main>
  );
}
