"use client";
import { displayScore } from "@/lib/grading";
import type { AttemptRow, ExamRow } from "./types";

export function Page({
  title,
  sub,
  children,
}: {
  title: string;
  sub?: string;
  children: React.ReactNode;
}) {
  return (
    <section>
      <div className="section-head">
        <div>
          <h2>{title}</h2>
          {sub && <p>{sub}</p>}
        </div>
      </div>
      {children}
    </section>
  );
}

export function Metric({ l, v }: { l: string; v: React.ReactNode }) {
  return (
    <article className="metric">
      <small>{l}</small>
      <strong>{v}</strong>
      <span>Đã đồng bộ</span>
    </article>
  );
}

export function Empty({ text }: { text: string }) {
  return (
    <div className="empty">
      ◇<p>{text}</p>
    </div>
  );
}

export function scoreOf(a: AttemptRow, exam?: ExamRow) {
  if (a.maxPoints > 0)
    return displayScore(a.points, a.maxPoints, exam?.scoring?.scale10 !== false);
  // Bài nộp từ trước bản vá: chỉ có số câu đúng.
  return a.maxScore > 0 ? Math.round((a.score / a.maxScore) * 1000) / 100 : 0;
}

export function Results({
  rows,
  exams,
}: {
  rows: AttemptRow[];
  exams: ExamRow[];
}) {
  const byId = new Map(exams.map((e) => [e.id, e]));
  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>
            <th>Học sinh</th>
            <th>Bài kiểm tra</th>
            <th>Điểm</th>
            <th>Số câu đúng</th>
            <th>Nộp lúc</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((a) => {
            const e = byId.get(a.examId);
            return (
              <tr key={a.id}>
                <td>
                  <b>{a.studentName}</b>
                  <small>{a.studentEmail}</small>
                </td>
                <td>
                  {e?.title ?? `#${a.examId}`}
                  {e && <small>Mã {e.code}</small>}
                </td>
                <td>
                  <b>{scoreOf(a, e).toFixed(2)}</b>
                </td>
                <td>
                  {a.score}/{a.maxScore}
                </td>
                <td>{new Date(a.submittedAt).toLocaleString("vi-VN")}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
      {!rows.length && <Empty text="Chưa có bài nộp." />}
    </div>
  );
}

export function exportCsv(rows: AttemptRow[], exams: ExamRow[]) {
  const byId = new Map(exams.map((e) => [e.id, e]));
  const head = "Hoc sinh,Email,Bai kiem tra,Ma bai,Diem,Cau dung,Tong cau,Nop luc\n";
  const body = rows
    .map((a) => {
      const e = byId.get(a.examId);
      const q = (s: unknown) => `"${String(s ?? "").replace(/"/g, '""')}"`;
      return [
        q(a.studentName),
        q(a.studentEmail),
        q(e?.title ?? a.examId),
        q(e?.code ?? ""),
        scoreOf(a, e).toFixed(2),
        a.score,
        a.maxScore,
        q(new Date(a.submittedAt).toLocaleString("vi-VN")),
      ].join(",");
    })
    .join("\n");

  const blob = new Blob(["\ufeff" + head + body], {
    type: "text/csv;charset=utf-8",
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `Ket_qua_V17_${new Date().toISOString().slice(0, 10)}.csv`;
  a.click();
  URL.revokeObjectURL(url); // bản cũ không thu hồi, rò bộ nhớ
}
