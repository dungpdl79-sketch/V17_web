"use client";
import { useState } from "react";
import { DEFAULT_SCORING } from "@/lib/grading";
import { Empty, Metric, Page, Results, exportCsv, scoreOf } from "./ui";
import type { Act, Data } from "./types";

export default function Teacher({
  active,
  data,
  busy,
  act,
}: {
  active: string;
  data: Data;
  busy: boolean;
  act: Act;
}) {
  const [className, setClassName] = useState("");
  const [form, setForm] = useState({ classId: "", duration: 45 });
  const [sc, setSc] = useState(DEFAULT_SCORING);
  const [file, setFile] = useState<File | null>(null);

  const byId = new Map(data.exams.map((e) => [e.id, e]));
  const scores = data.attempts.map((a) => scoreOf(a, byId.get(a.examId)));
  const avg = scores.length ? scores.reduce((s, x) => s + x, 0) / scores.length : 0;

  /* ---------------- Lớp học ---------------- */
  if (active === "Lớp học")
    return (
      <Page
        title="Danh sách lớp"
        sub="Tạo mã lớp để học sinh tham gia trên mọi thiết bị."
      >
        <form
          className="inline-form"
          onSubmit={(e) => {
            e.preventDefault();
            act({ action: "createClass", name: className });
            setClassName("");
          }}
        >
          <input
            value={className}
            onChange={(e) => setClassName(e.target.value)}
            placeholder="Ví dụ: Toán 12A09"
          />
          <button disabled={busy || !className}>＋ Tạo lớp</button>
        </form>
        <div className="card-grid">
          {data.classes.map((c) => (
            <article className="class-card" key={c.id}>
              <div className="class-icon">12</div>
              <div>
                <h3>{c.name}</h3>
                <p>
                  {c.students ?? 0} học sinh · {c.schoolYear}
                </p>
                <span>
                  Mã lớp: <b>{c.code}</b>
                </span>
              </div>
            </article>
          ))}
          {!data.classes.length && <Empty text="Chưa có lớp học." />}
        </div>
      </Page>
    );

  /* ---------------- Studio đề ---------------- */
  if (active === "Studio đề")
    return (
      <Page
        title="Studio thiết kế và phát đề"
        sub="Soạn đề ở V15, xuất JSON rồi nạp lên đây để phát cho học sinh."
      >
        <div className="studio">
          <div className="steps">
            {["Soạn ở V15", "Chọn lớp", "Thang điểm", "Nạp file", "Phát bài"].map(
              (x, i) => (
                <div className="step" key={x}>
                  <b>{i + 1}</b>
                  {x}
                </div>
              )
            )}
          </div>

          <div className="studio-form">
            <a
              href="/v15.html"
              target="_blank"
              rel="noopener noreferrer"
              className="primary-btn v15-link"
            >
              🚀 Mở xưởng soạn đề V15 (đầy đủ công thức &amp; ma trận)
            </a>
            <hr />

            <h3>📥 Nạp đề từ V15 và phát cho học sinh</h3>

            <label>
              Chọn lớp
              <select
                value={form.classId}
                onChange={(e) => setForm({ ...form, classId: e.target.value })}
              >
                <option value="">— Chọn lớp —</option>
                {data.classes.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </label>

            <label>
              Thời gian làm bài (phút)
              <input
                type="number"
                min={5}
                max={180}
                value={form.duration}
                onChange={(e) =>
                  setForm({ ...form, duration: Number(e.target.value) })
                }
              />
            </label>

            {/* Khôi phục thang điểm của V15 — bản cũ chấm 1 điểm/câu. */}
            <fieldset className="scoring-box">
              <legend>Thang điểm</legend>
              <label className="row">
                Mỗi câu trắc nghiệm
                <input
                  type="number"
                  step="0.05"
                  min="0"
                  value={sc.mcq}
                  onChange={(e) => setSc({ ...sc, mcq: Number(e.target.value) })}
                />
              </label>
              <label className="row">
                Mỗi câu trả lời ngắn
                <input
                  type="number"
                  step="0.05"
                  min="0"
                  value={sc.sa}
                  onChange={(e) => setSc({ ...sc, sa: Number(e.target.value) })}
                />
              </label>
              <div className="row">
                <span>Đúng/Sai: 1 – 2 – 3 – 4 ý đúng</span>
                <div className="tf-inputs">
                  {[1, 2, 3, 4].map((k) => (
                    <input
                      key={k}
                      type="number"
                      step="0.05"
                      min="0"
                      value={sc.tf[k]}
                      onChange={(e) => {
                        const tf = [...sc.tf];
                        tf[k] = Number(e.target.value);
                        setSc({ ...sc, tf });
                      }}
                    />
                  ))}
                </div>
              </div>
              <label className="row check">
                <input
                  type="checkbox"
                  checked={sc.scale10}
                  onChange={(e) => setSc({ ...sc, scale10: e.target.checked })}
                />
                Quy đổi kết quả về thang 10
              </label>
            </fieldset>

            <label>
              File sao lưu (.json) từ V15
              <input
                type="file"
                accept=".json,application/json"
                className="file-input"
                onChange={(e) => setFile(e.target.files?.[0] ?? null)}
              />
            </label>

            <button
              className="primary-btn"
              disabled={!form.classId || !file || busy}
              onClick={async () => {
                if (!file) return;
                let jsonData: Record<string, unknown>;
                try {
                  jsonData = JSON.parse(await file.text());
                } catch {
                  alert("File JSON không hợp lệ.");
                  return;
                }
                await act({
                  action: "importJsonExam",
                  classId: Number(form.classId),
                  duration: form.duration,
                  title: file.name.replace(/\.[^/.]+$/, ""),
                  scoring: sc,
                  jsonData,
                });
              }}
            >
              🚀 Nạp đề &amp; phát bài
            </button>
          </div>
        </div>
      </Page>
    );

  /* ---------------- Ngân hàng / quản lý bài ---------------- */
  if (active === "Ngân hàng")
    return (
      <Page
        title="Quản lý bài kiểm tra đã phát"
        sub="Nên ĐÓNG bài khi hết hạn thay vì xoá, để giữ kết quả của học sinh."
      >
        <div className="panel">
          {data.exams.map((e) => {
            const n = data.attempts.filter((a) => a.examId === e.id).length;
            return (
              <div className="list-row" key={e.id}>
                <div>
                  <b>{e.title}</b>
                  <small>
                    Mã {e.code} · {e.durationMinutes} phút ·{" "}
                    {e.publicQuestions.length} câu · {n} lượt nộp ·{" "}
                    <span className={`badge ${e.status}`}>{e.status}</span>
                  </small>
                </div>
                <div className="row-actions">
                  <button
                    disabled={busy}
                    onClick={() =>
                      act({
                        action: "setExamStatus",
                        examId: e.id,
                        status: e.status === "open" ? "closed" : "open",
                      })
                    }
                  >
                    {e.status === "open" ? "🔒 Đóng bài" : "🔓 Mở lại"}
                  </button>
                  <button
                    className="danger"
                    disabled={busy}
                    onClick={async () => {
                      if (!confirm(`Xoá bài "${e.title}"?`)) return;
                      const r = await act({ action: "deleteExam", examId: e.id });
                      const err = (r as { error?: string })?.error;
                      if (
                        err &&
                        confirm(`${err}\n\nVẫn xoá cả ${n} bài nộp?`)
                      )
                        await act({
                          action: "deleteExam",
                          examId: e.id,
                          confirmDeleteAttempts: true,
                        });
                    }}
                  >
                    🗑️ Xoá
                  </button>
                </div>
              </div>
            );
          })}
          {!data.exams.length && <Empty text="Chưa có bài kiểm tra nào." />}
        </div>
      </Page>
    );

  /* ---------------- Kết quả ---------------- */
  if (active === "Kết quả")
    return (
      <Page title="Bảng kết quả" sub="Dữ liệu nộp từ mọi thiết bị.">
        <button
          className="mb"
          onClick={() => exportCsv(data.attempts, data.exams)}
        >
          ⬇ Xuất Excel/CSV
        </button>
        <Results rows={data.attempts} exams={data.exams} />
      </Page>
    );

  /* ---------------- Nhật ký & an toàn ---------------- */
  if (active === "An toàn")
    return (
      <Page
        title="An toàn dữ liệu"
        sub="Những gì hệ thống thực sự đang làm (không phải khẩu hiệu)."
      >
        <div className="security-grid">
          {[
            ["Mật khẩu băm PBKDF2", "150.000 vòng, muối riêng từng tài khoản."],
            ["Phiên ở máy chủ", "Cookie HttpOnly, hết hạn sau 7 ngày, đăng xuất xoá phiên thật."],
            ["Đáp án không rời máy chủ", "Kể cả các ý Đúng/Sai."],
            ["Nộp một lần", "Kiểm tra trước khi chấm nên không dò được đáp án."],
            ["Đếm giờ ở máy chủ", "Thời điểm bắt đầu do máy chủ ghi, quá giờ không nhận bài."],
            ["Nhật ký", "Ghi tạo lớp, phát đề, bắt đầu, nộp bài và đăng nhập."],
          ].map(([t, d]) => (
            <article key={t}>
              <b>✓ {t}</b>
              <p>{d}</p>
            </article>
          ))}
        </div>
        <p className="hint">
          Sao lưu định kỳ bằng lệnh:{" "}
          <code>npx wrangler d1 export dinhcaotritue-db --remote --output=backup.sql</code>
        </p>
      </Page>
    );

  /* ---------------- Tổng quan ---------------- */
  return (
    <Page
      title={`Chào ${data.user.name}`}
      sub="Lớp học đã sẵn sàng và đồng bộ an toàn."
    >
      <div className="metric-row">
        <Metric l="Lớp" v={data.classes.length} />
        <Metric
          l="Học sinh"
          v={data.classes.reduce((s, c) => s + (c.students ?? 0), 0)}
        />
        <Metric l="Bài đã phát" v={data.exams.length} />
        <Metric l="Điểm TB" v={scores.length ? avg.toFixed(2) : "—"} />
      </div>
      <div className="panel">
        <h3>Bài gần đây</h3>
        {data.exams.slice(0, 8).map((e) => (
          <div className="list-row" key={e.id}>
            <div>
              <b>{e.title}</b>
              <small>
                Mã {e.code} · {e.durationMinutes} phút ·{" "}
                <span className={`badge ${e.status}`}>{e.status}</span>
              </small>
            </div>
            <span>
              {data.attempts.filter((a) => a.examId === e.id).length} lượt nộp
            </span>
          </div>
        ))}
        {!data.exams.length && <Empty text="Chưa phát bài nào." />}
      </div>
    </Page>
  );
}
