"use client";
import { useEffect, useRef } from "react";
import { sanitize } from "@/lib/sanitize-client";

type MathJaxLike = { typesetPromise?: (els?: Element[]) => Promise<void> };

/** Gọi MathJax; nếu thư viện chưa tải xong thì thử lại tối đa ~6 giây. */
export function typeset(el: Element | null, tries = 20) {
  if (!el) return;
  const mj = (window as unknown as { MathJax?: MathJaxLike }).MathJax;
  if (mj?.typesetPromise) {
    mj.typesetPromise([el]).catch(() => {});
    return;
  }
  if (tries > 0) setTimeout(() => typeset(el, tries - 1), 300);
}

export default function SafeHtml({
  html,
  className,
}: {
  html: string;
  className?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    el.innerHTML = sanitize(html);
    typeset(el);
  }, [html]);

  // Trước khi hydrate, hiển thị chữ thuần để không bao giờ trống trang.
  return <div ref={ref} className={className} suppressHydrationWarning />;
}
