"use client";
import { useState } from "react";
import ExamPlayer from "./exam-player";
import { Empty, Metric, Page, scoreOf } from "./ui";
import type { Act, Data, ExamAnswers } from "./types";

export default function Student({
  active,
  data,
  busy,
  act,
}: {
  active: string;
  data: Data;
  busy: boolean;
  act: Act;
}) {
  const [join, setJoin] = useState("");

  if (active === "Lớp của em")
    return (
      <Page title="Lớp của em" sub="Nhập mã lớp do giáo viên cung cấp.">
        <form
          className="inline-form"
          onSubmit={(e) => {
            e.preventDefault();
            act({ action: "joinClass", code: join });
            setJoin("");
          }}
        >
          <input
            value={join}
            onChange={(e) => setJoin(e.target.value.toUpperCase())}
            placeholder="MÃ LỚP"
            maxLength={8}
          />
          <button disabled={busy || !join}>Tham gia</button>
        </form>
        <div className="card-grid">
          {data.classes.map((c) => (
            <article className="class-card" key={c.id}>
              <div className="class-icon">12</div>
              <div>
                <h3>{c.name}</h3>
                <p>{c.schoolYear}</p>
              </div>
            </article>
          ))}
          {!data.classes.length && <Empty text="Em chưa tham gia lớp nào." />}
        </div>
      </Page>
    );

  if (active === "Kết quả" || active === "Năng lực") {
    const byId = new Map(data.exams.map((e) => [e.id, e]));
    const scores = data.attempts.map((a) => scoreOf(a, byId.get(a.examId)));
    const avg = scores.length
      ? scores.reduce((s, x) => s + x, 0) / scores.length
      : 0;
    return (
      <Page title={active} sub="Kết quả được chấm và lưu ở máy chủ.">
        <div className="metric-row">
          <Metric l="Bài đã nộp" v={data.attempts.length} />
          <Metric
            l="Điểm cao nhất"
            v={scores.length ? Math.max(...scores).toFixed(2) : "—"}
          />
          <Metric l="Điểm trung bình" v={scores.length ? avg.toFixed(2) : "—"} />
        </div>
        <div className="panel">
          <h3>Chi tiết</h3>
          {data.attempts.map((a) => {
            const e = byId.get(a.examId);
            return (
              <div className="list-row" key={a.id}>
                <div>
                  <b>{e?.title ?? `Bài #${a.examId}`}</b>
                  <small>
                    {a.score}/{a.maxScore} câu đúng ·{" "}
                    {new Date(a.submittedAt).toLocaleString("vi-VN")}
                  </small>
                </div>
                <b>{scoreOf(a, e).toFixed(2)}</b>
              </div>
            );
          })}
          {!data.attempts.length && <Empty text="Em chưa nộp bài nào." />}
        </div>
      </Page>
    );
  }

  /* ---------------- Bài cần làm ---------------- */
  const startMap = new Map(data.examStarts.map((s) => [s.examId, s.startedAt]));

  return (
    <Page
      title={`Chào ${data.user.name}`}
      sub="Bài tập được đồng bộ trực tiếp từ giáo viên."
    >
      <div className="exam-list">
        {data.exams.map((e) => {
          const done = data.attempts.find((a) => a.examId === e.id);
          return (
            <article className="exam-card" key={e.id}>
              <span>
                TOÁN 12 · {e.durationMinutes} phút · {e.publicQuestions.length} câu
              </span>
              <h3>{e.title}</h3>
              <p>
                Mã bài <b>{e.code}</b>
              </p>

              {done ? (
                <div className="done">
                  ✓ Đã nộp — {scoreOf(done, e).toFixed(2)} điểm ({done.score}/
                  {done.maxScore} câu đúng)
                </div>
              ) : (
                <ExamPlayer
                  exam={e}
                  busy={busy}
                  startedAt={startMap.get(e.id) ?? null}
                  onStart={async () => {
                    await act({ action: "startExam", examId: e.id });
                  }}
                  onSubmit={async (answers: ExamAnswers) => {
                    await act({
                      action: "submitExam",
                      examId: e.id,
                      answers,
                    });
                  }}
                />
              )}
            </article>
          );
        })}
        {!data.exams.length && <Empty text="Chưa có bài cần làm." />}
      </div>
    </Page>
  );
}
