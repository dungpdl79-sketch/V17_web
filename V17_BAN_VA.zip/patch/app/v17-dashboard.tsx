"use client";
import { useCallback, useEffect, useState } from "react";
import Student from "./components/student";
import Teacher from "./components/teacher";
import type { Data, UserInfo } from "./components/types";

const TEACHER_MENU = [
  "Tổng quan",
  "Lớp học",
  "Studio đề",
  "Ngân hàng",
  "Kết quả",
  "An toàn",
];
const STUDENT_MENU = ["Bài cần làm", "Lớp của em", "Kết quả"];

const ICON: Record<string, string> = {
  "Tổng quan": "⌂",
  "Lớp học": "▦",
  "Studio đề": "✦",
  "Ngân hàng": "▤",
  "Kết quả": "◉",
  "An toàn": "⛨",
  "Bài cần làm": "✎",
  "Lớp của em": "▦",
};

export default function Dashboard({ initialUser }: { initialUser: UserInfo }) {
  const teacher = initialUser.role === "teacher";
  const [data, setData] = useState<Data>({
    user: initialUser,
    classes: [],
    exams: [],
    attempts: [],
    examStarts: [],
  });
  const [active, setActive] = useState(teacher ? "Tổng quan" : "Bài cần làm");
  const [busy, setBusy] = useState(false);
  const [note, setNote] = useState("");

  const load = useCallback(async () => {
    try {
      const r = await fetch("/api/v17", { cache: "no-store" });
      const j = await r.json();
      if (r.ok) setData(j);
      else if (r.status === 401) window.location.reload();
      else setNote(j.error);
    } catch {
      setNote("Mất kết nối máy chủ.");
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const act = useCallback(
    async (payload: Record<string, unknown>) => {
      setBusy(true);
      try {
        const r = await fetch("/api/v17", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify(payload),
        });
        const j = await r.json();
        if (r.ok) {
          if (j.display !== undefined)
            setNote(
              `Đã nộp bài: ${Number(j.display).toFixed(2)} điểm (${j.correctCount}/${j.total} câu đúng).`
            );
          else if (j.skipped?.length)
            setNote(
              `Đã phát đề (${j.count}/${j.total} câu). Bỏ qua: ${j.skipped.join("; ")}`
            );
          else setNote("Đã lưu thành công.");
          await load();
        } else if (r.status === 401) {
          window.location.reload();
        } else {
          setNote(j.error);
        }
        return j;
      } catch {
        setNote("Không gửi được yêu cầu.");
        return { error: "network" };
      } finally {
        setBusy(false);
      }
    },
    [load]
  );

  const logout = async () => {
    await fetch("/api/auth", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ mode: "logout" }),
    });
    window.location.href = "/";
  };

  const menu = teacher ? TEACHER_MENU : STUDENT_MENU;
  const initial = (data.user.name || data.user.email || "?").trim()[0] ?? "?";

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="logo">
          <b>Đ</b>
          <span>
            Đỉnh Cao
            <br />
            <small>TRÍ TUỆ V17</small>
          </span>
        </div>
        <nav>
          {menu.map((x) => (
            <button
              key={x}
              className={active === x ? "active" : ""}
              onClick={() => setActive(x)}
            >
              <i>{ICON[x]}</i>
              {x}
            </button>
          ))}
        </nav>
        <div className="side-footer">
          <div className="avatar">{initial}</div>
          <div>
            <b>{data.user.name}</b>
            <small>{teacher ? "Giáo viên" : "Học sinh"}</small>
          </div>
          {/* Bản cũ trỏ vào /signout-with-chatgpt nên không xoá được phiên. */}
          <button className="logout" onClick={logout} title="Đăng xuất">
            ⏻
          </button>
        </div>
      </aside>

      <main className="workspace">
        <header>
          <div>
            <p className="eyebrow">NĂM HỌC 2026–2027</p>
            <h1>{active}</h1>
          </div>
          <div className="header-actions">
            <span>● Đã đồng bộ</span>
            <button onClick={() => window.print()}>In / Xuất PDF</button>
          </div>
        </header>

        {note && (
          <div className="notice">
            {note}
            <button onClick={() => setNote("")}>×</button>
          </div>
        )}

        {teacher ? (
          <Teacher active={active} data={data} busy={busy} act={act} />
        ) : (
          <Student active={active} data={data} busy={busy} act={act} />
        )}
      </main>
    </div>
  );
}
