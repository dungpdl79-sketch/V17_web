/* ============================================================================
   CHẤM ĐIỂM — dùng chung, chạy phía MÁY CHỦ.
   Khôi phục thang điểm của V15: trắc nghiệm 0,25 · trả lời ngắn 0,5 ·
   đúng/sai bậc thang 0,1 / 0,25 / 0,5 / 1 theo số ý đúng · quy đổi thang 10.
   ========================================================================== */

export type Scoring = {
  mcq: number;
  sa: number;
  /** tf[k] = điểm khi đúng k ý (k = 0..4) */
  tf: number[];
  scale10: boolean;
};

export const DEFAULT_SCORING: Scoring = {
  mcq: 0.25,
  sa: 0.5,
  tf: [0, 0.1, 0.25, 0.5, 1],
  scale10: true,
};

export function normalizeScoring(raw: unknown): Scoring {
  const r = (raw ?? {}) as Partial<Scoring>;
  const tf = Array.isArray(r.tf) && r.tf.length >= 5
    ? r.tf.slice(0, 5).map((x) => Number(x) || 0)
    : DEFAULT_SCORING.tf;
  return {
    mcq: Number.isFinite(Number(r.mcq)) ? Number(r.mcq) : DEFAULT_SCORING.mcq,
    sa: Number.isFinite(Number(r.sa)) ? Number(r.sa) : DEFAULT_SCORING.sa,
    tf,
    scale10: r.scale10 !== false,
  };
}

/* ---------------- Đáp án ---------------------------------------------------- */

export type KeyItem =
  | { type: "mcq"; ans: number }
  | { type: "tf"; ans: boolean[] }
  | { type: "sa"; ans: string };

/** Chấp nhận cả định dạng cũ ({q1: 0}) lẫn định dạng mới ({q1:{type,ans}}). */
export function normalizeAnswerKey(raw: unknown): Record<string, KeyItem> {
  const src = (raw ?? {}) as Record<string, unknown>;
  const out: Record<string, KeyItem> = {};
  for (const [k, v] of Object.entries(src)) {
    if (v && typeof v === "object" && "type" in (v as object)) {
      const item = v as KeyItem;
      if (item.type === "tf") {
        out[k] = { type: "tf", ans: (item.ans as unknown[]).map(Boolean) };
      } else if (item.type === "mcq") {
        out[k] = { type: "mcq", ans: Number(item.ans) };
      } else {
        out[k] = { type: "sa", ans: String(item.ans ?? "") };
      }
      continue;
    }
    // Định dạng cũ
    if (Array.isArray(v)) out[k] = { type: "tf", ans: v.map(Boolean) };
    else if (typeof v === "number") out[k] = { type: "mcq", ans: v };
    else out[k] = { type: "sa", ans: String(v ?? "") };
  }
  return out;
}

/* ---------------- Chuẩn hoá câu trả lời ngắn -------------------------------- */

export function normSA(v: unknown) {
  let s = String(v ?? "")
    .trim()
    .toLowerCase()
    .replace(/\s+/g, "");
  if (!s) return "";
  // 1,5 -> 1.5 (chỉ khi dấu phẩy nằm giữa hai chữ số)
  s = s.replace(/(\d),(\d)/g, "$1.$2");
  const n = Number(s);
  if (Number.isFinite(n)) return String(Math.round(n * 1e6) / 1e6); // 2.50 -> 2.5
  return s;
}

/* ---------------- Chấm từng câu --------------------------------------------- */

export type OneResult = {
  points: number;
  maxPoints: number;
  correct: boolean;
  correctCount?: number;
};

export function gradeOne(
  key: KeyItem,
  given: unknown,
  sc: Scoring
): OneResult {
  if (key.type === "mcq") {
    const ok = String(given ?? "").trim() === String(key.ans).trim();
    return { points: ok ? sc.mcq : 0, maxPoints: sc.mcq, correct: ok };
  }

  if (key.type === "tf") {
    const n = Math.min(key.ans.length, 4);
    const arr = Array.isArray(given) ? (given as unknown[]) : [];
    let cnt = 0;
    for (let i = 0; i < n; i++) {
      const g = String(arr[i] ?? "").toUpperCase();
      if (g !== "T" && g !== "F") continue; // bỏ trống => không tính đúng
      if ((g === "T") === Boolean(key.ans[i])) cnt++;
    }
    const idx = Math.min(cnt, sc.tf.length - 1);
    const maxIdx = Math.min(n, sc.tf.length - 1);
    return {
      points: sc.tf[idx] ?? 0,
      maxPoints: sc.tf[maxIdx] ?? 0,
      correct: cnt === n,
      correctCount: cnt,
    };
  }

  const ok = normSA(given) !== "" && normSA(given) === normSA(key.ans);
  return { points: ok ? sc.sa : 0, maxPoints: sc.sa, correct: ok };
}

/* ---------------- Chấm cả bài ------------------------------------------------ */

export type ExamResult = {
  points: number;
  maxPoints: number;
  correctCount: number;
  total: number;
  score10: number;
  perQuestion: Record<string, OneResult>;
};

export function gradeAll(
  key: Record<string, KeyItem>,
  answers: Record<string, unknown>,
  sc: Scoring
): ExamResult {
  let points = 0;
  let maxPoints = 0;
  let correctCount = 0;
  const perQuestion: Record<string, OneResult> = {};

  for (const [qid, k] of Object.entries(key)) {
    const r = gradeOne(k, answers?.[qid], sc);
    perQuestion[qid] = r;
    points += r.points;
    maxPoints += r.maxPoints;
    if (r.correct) correctCount++;
  }

  const round = (x: number) => Math.round(x * 100) / 100;
  const score10 =
    maxPoints > 0 ? round((points / maxPoints) * 10) : 0;

  return {
    points: round(points),
    maxPoints: round(maxPoints),
    correctCount,
    total: Object.keys(key).length,
    score10,
    perQuestion,
  };
}

/** Điểm hiển thị cuối cùng: quy đổi thang 10 hoặc giữ điểm thô. */
export function displayScore(
  points: number,
  maxPoints: number,
  scale10: boolean
) {
  if (!scale10) return Math.round(points * 100) / 100;
  return maxPoints > 0 ? Math.round((points / maxPoints) * 1000) / 100 : 0;
}
