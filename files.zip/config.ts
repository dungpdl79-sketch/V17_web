/* ============================================================================
   CẤU HÌNH BẢO MẬT — THẦY SỬA FILE NÀY TRƯỚC KHI TRIỂN KHAI
   ========================================================================== */

/** Email được cấp vai trò GIÁO VIÊN khi đăng ký. Mọi email khác => HỌC SINH. */
export const TEACHER_EMAILS: string[] = [
  "thuyetdung@gmail.com", // ← ĐỔI thành email thật của thầy
  // "toantruong@thpt-abc.edu.vn",
];

/** Mã bắt buộc khi đăng ký một email nằm trong TEACHER_EMAILS.
 *  Chặn người lạ đăng ký trước bằng email của giáo viên. */
export const TEACHER_SIGNUP_CODE = "DOI-MA-NAY-NGAY-1234";

/** Mã kích hoạt cho các tài khoản ĐÃ CÓ trong CSDL từ bản V17 cũ
 *  (những tài khoản chưa có mật khẩu). Thầy đọc mã này cho lớp một lần. */
export const LEGACY_ACTIVATION_CODE = "KICHHOAT-2026";

/** Thời hạn phiên đăng nhập (giây). Mặc định 7 ngày. */
export const SESSION_TTL_SECONDS = 60 * 60 * 24 * 7;

/** Ân hạn khi nộp bài trễ so với thời gian quy định (giây). */
export const SUBMIT_GRACE_SECONDS = 90;

export function isTeacherEmail(email: string) {
  return TEACHER_EMAILS.map((e) => e.trim().toLowerCase()).includes(
    email.trim().toLowerCase()
  );
}
