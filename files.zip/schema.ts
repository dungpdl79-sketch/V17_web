import {
  integer,
  real,
  sqliteTable,
  text,
  uniqueIndex,
} from "drizzle-orm/sqlite-core";

/* ---------------------------------------------------------------------------
   users — THÊM passwordHash / passwordSalt.
   Vai trò do máy chủ quyết định lúc đăng ký (theo TEACHER_EMAILS),
   KHÔNG cho phép người dùng tự đặt như bản cũ.
   ------------------------------------------------------------------------- */
export const users = sqliteTable("users", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  email: text("email").notNull().unique(),
  name: text("name").notNull(),
  role: text("role", { enum: ["teacher", "student"] }).notNull(),
  passwordHash: text("password_hash"),
  passwordSalt: text("password_salt"),
  createdAt: text("created_at").notNull(),
});

/* ---------------------------------------------------------------------------
   sessions — phiên đăng nhập lưu ở máy chủ.
   Cookie chỉ chứa token ngẫu nhiên; CSDL lưu SHA-256 của token.
   Nhờ vậy: không giả mạo được, đăng xuất thật sự, có hạn dùng.
   ------------------------------------------------------------------------- */
export const sessions = sqliteTable("sessions", {
  id: text("id").primaryKey(), // sha256(token)
  email: text("email").notNull(),
  createdAt: text("created_at").notNull(),
  expiresAt: text("expires_at").notNull(),
});

export const classes = sqliteTable("classes", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  teacherEmail: text("teacher_email").notNull(),
  name: text("name").notNull(),
  code: text("code").notNull().unique(),
  schoolYear: text("school_year").notNull(),
  createdAt: text("created_at").notNull(),
});

export const memberships = sqliteTable(
  "memberships",
  {
    id: integer("id").primaryKey({ autoIncrement: true }),
    classId: integer("class_id").notNull(),
    studentEmail: text("student_email").notNull(),
    joinedAt: text("joined_at").notNull(),
  },
  (t) => [uniqueIndex("membership_unique").on(t.classId, t.studentEmail)]
);

/* ---------------------------------------------------------------------------
   exams — THÊM cột scoring (JSON thang điểm lấy từ V15).
   publicQuestions: ĐÃ LƯỢC đáp án trước khi ghi (kể cả stmts).
   answerKey: dạng mới { q1: {type, ans}, ... }
   ------------------------------------------------------------------------- */
export const exams = sqliteTable("exams", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  classId: integer("class_id").notNull(),
  teacherEmail: text("teacher_email").notNull(),
  title: text("title").notNull(),
  code: text("code").notNull().unique(),
  durationMinutes: integer("duration_minutes").notNull().default(45),
  publicQuestions: text("public_questions").notNull(),
  answerKey: text("answer_key").notNull(),
  scoring: text("scoring").notNull().default("{}"),
  status: text("status", { enum: ["draft", "open", "closed"] })
    .notNull()
    .default("open"),
  createdAt: text("created_at").notNull(),
});

/* ---------------------------------------------------------------------------
   examStarts — thời điểm BẮT ĐẦU do máy chủ ghi.
   Đây là căn cứ duy nhất để tính giờ; máy học sinh không tự khai được.
   ------------------------------------------------------------------------- */
export const examStarts = sqliteTable(
  "exam_starts",
  {
    id: integer("id").primaryKey({ autoIncrement: true }),
    examId: integer("exam_id").notNull(),
    studentEmail: text("student_email").notNull(),
    startedAt: text("started_at").notNull(),
  },
  (t) => [uniqueIndex("exam_start_unique").on(t.examId, t.studentEmail)]
);

/* ---------------------------------------------------------------------------
   attempts — THÊM points / maxPoints (điểm thực theo thang của V15).
   score / maxScore giữ nguyên = số câu đúng / tổng số câu (tương thích cũ).
   ------------------------------------------------------------------------- */
export const attempts = sqliteTable(
  "attempts",
  {
    id: integer("id").primaryKey({ autoIncrement: true }),
    examId: integer("exam_id").notNull(),
    studentEmail: text("student_email").notNull(),
    studentName: text("student_name").notNull(),
    answers: text("answers").notNull(),
    score: integer("score").notNull(),
    maxScore: integer("max_score").notNull(),
    points: real("points").notNull().default(0),
    maxPoints: real("max_points").notNull().default(0),
    startedAt: text("started_at").notNull(),
    submittedAt: text("submitted_at").notNull(),
  },
  (t) => [uniqueIndex("attempt_unique").on(t.examId, t.studentEmail)]
);

export const auditLogs = sqliteTable("audit_logs", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  actorEmail: text("actor_email").notNull(),
  action: text("action").notNull(),
  entityType: text("entity_type").notNull(),
  entityId: text("entity_id").notNull(),
  details: text("details").notNull(),
  createdAt: text("created_at").notNull(),
});
