import { and, desc, eq, inArray } from "drizzle-orm";
import { getDb } from "@/db";
import {
  attempts,
  auditLogs,
  classes,
  examStarts,
  exams,
  memberships,
  users,
} from "@/db/schema";
import { getUserByToken, readTokenFromCookieHeader } from "@/lib/auth";
import { SUBMIT_GRACE_SECONDS } from "@/lib/config";
import {
  DEFAULT_SCORING,
  displayScore,
  gradeAll,
  normalizeAnswerKey,
  normalizeScoring,
} from "@/lib/grading";
import { buildExamFromV15, stripAnswers } from "@/lib/import-v15";

const now = () => new Date().toISOString();

/** Mã lớp/mã đề dùng crypto thay cho Math.random, và có thử lại khi trùng. */
function makeCode() {
  const ALPHA = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const buf = new Uint8Array(6);
  crypto.getRandomValues(buf);
  return [...buf].map((b) => ALPHA[b % ALPHA.length]).join("");
}

const clean = (v: unknown, n = 120) =>
  String(v ?? "").replace(/[<>]/g, "").trim().slice(0, n);

function fail(msg: string, status = 400) {
  return Response.json({ error: msg }, { status });
}

async function auth(req: Request) {
  return getUserByToken(readTokenFromCookieHeader(req.headers.get("cookie")));
}

/** Nhật ký — bảng audit_logs của bản cũ chưa từng được ghi. Nay ghi thật. */
async function log(
  actorEmail: string,
  action: string,
  entityType: string,
  entityId: string | number,
  details: unknown
) {
  try {
    await getDb().insert(auditLogs).values({
      actorEmail,
      action,
      entityType,
      entityId: String(entityId),
      details: JSON.stringify(details).slice(0, 1000),
      createdAt: now(),
    });
  } catch {
    /* nhật ký hỏng không được làm hỏng nghiệp vụ */
  }
}

/* ===========================================================================
   GET — nạp dữ liệu bảng điều khiển
   =========================================================================== */
export async function GET(req: Request) {
  try {
    const me = await auth(req);
    if (!me) return fail("Chưa đăng nhập", 401);
    const db = getDb();

    /* ---------------- GIÁO VIÊN ---------------- */
    if (me.role === "teacher") {
      const cs = await db
        .select()
        .from(classes)
        .where(eq(classes.teacherEmail, me.email))
        .orderBy(desc(classes.id));
      const ids = cs.map((x) => x.id);

      const [es, ms] = await Promise.all([
        ids.length
          ? db.select().from(exams).where(inArray(exams.classId, ids)).orderBy(desc(exams.id))
          : Promise.resolve([]),
        ids.length
          ? db.select().from(memberships).where(inArray(memberships.classId, ids))
          : Promise.resolve([]),
      ]);

      const ei = es.map((x) => x.id);
      const at = ei.length
        ? await db.select().from(attempts).where(inArray(attempts.examId, ei)).orderBy(desc(attempts.id))
        : [];

      return Response.json({
        user: me,
        classes: cs.map((c) => ({
          ...c,
          students: ms.filter((m) => m.classId === c.id).length,
        })),
        // answerKey KHÔNG bao giờ rời máy chủ; publicQuestions lọc lần hai.
        exams: es.map(({ answerKey: _k, ...e }) => ({
          ...e,
          scoring: safeParse(e.scoring, DEFAULT_SCORING),
          publicQuestions: stripAnswers(safeParse(e.publicQuestions, [])),
        })),
        attempts: at,
        examStarts: [],
      });
    }

    /* ---------------- HỌC SINH ---------------- */
    const ms = await db
      .select()
      .from(memberships)
      .where(eq(memberships.studentEmail, me.email));
    const ids = ms.map((x) => x.classId);

    const cs = ids.length
      ? await db.select().from(classes).where(inArray(classes.id, ids))
      : [];
    const es = ids.length
      ? await db
          .select()
          .from(exams)
          .where(and(inArray(exams.classId, ids), eq(exams.status, "open")))
      : [];
    const ei = es.map((x) => x.id);

    const [at, st] = await Promise.all([
      ei.length
        ? db
            .select()
            .from(attempts)
            .where(and(inArray(attempts.examId, ei), eq(attempts.studentEmail, me.email)))
            .orderBy(desc(attempts.id))
        : Promise.resolve([]),
      ei.length
        ? db
            .select()
            .from(examStarts)
            .where(and(inArray(examStarts.examId, ei), eq(examStarts.studentEmail, me.email)))
        : Promise.resolve([]),
    ]);

    return Response.json({
      user: me,
      classes: cs,
      exams: es.map(({ answerKey: _k, ...e }) => ({
        ...e,
        scoring: safeParse(e.scoring, DEFAULT_SCORING),
        publicQuestions: stripAnswers(safeParse(e.publicQuestions, [])),
      })),
      attempts: at,
      examStarts: st,
    });
  } catch (e) {
    return Response.json(
      { error: e instanceof Error ? e.message : "Lỗi máy chủ" },
      { status: 500 }
    );
  }
}

function safeParse<T>(s: string, fallback: T): T {
  try {
    const v = JSON.parse(s);
    return v ?? fallback;
  } catch {
    return fallback;
  }
}

/* ===========================================================================
   POST — các hành động
   =========================================================================== */
export async function POST(req: Request) {
  try {
    const me = await auth(req);
    if (!me) return fail("Chưa đăng nhập", 401);

    const b = (await req.json()) as Record<string, unknown>;
    const action = clean(b.action, 30);
    const db = getDb();

    /* ---------------- GIÁO VIÊN: tạo lớp ---------------- */
    if (action === "createClass") {
      if (me.role !== "teacher") return fail("Không đủ quyền", 403);
      const name = clean(b.name, 80);
      if (!name) return fail("Thiếu tên lớp");

      // Thử lại khi mã trùng thay vì ném lỗi 500 như bản cũ.
      for (let i = 0; i < 5; i++) {
        const code = makeCode();
        const [dup] = await db.select().from(classes).where(eq(classes.code, code)).limit(1);
        if (dup) continue;
        await db.insert(classes).values({
          teacherEmail: me.email,
          name,
          code,
          schoolYear: clean(b.schoolYear, 20) || "2026–2027",
          createdAt: now(),
        });
        await log(me.email, "createClass", "class", code, { name });
        return Response.json({ ok: true, code });
      }
      return fail("Không sinh được mã lớp, thử lại.", 500);
    }

    /* ---------------- HỌC SINH: vào lớp ---------------- */
    if (action === "joinClass") {
      if (me.role !== "student") return fail("Không đủ quyền", 403);
      const code = clean(b.code, 8).toUpperCase();
      const [c] = await db.select().from(classes).where(eq(classes.code, code)).limit(1);
      if (!c) return fail("Mã lớp không tồn tại", 404);
      await db
        .insert(memberships)
        .values({ classId: c.id, studentEmail: me.email, joinedAt: now() })
        .onConflictDoNothing();
      await log(me.email, "joinClass", "class", c.id, { code });
      return Response.json({ ok: true });
    }

    /* ---------------- GIÁO VIÊN: nạp đề từ V15 ---------------- */
    if (action === "importJsonExam") {
      if (me.role !== "teacher") return fail("Không đủ quyền", 403);
      const classId = Number(b.classId);
      const [c] = await db
        .select()
        .from(classes)
        .where(and(eq(classes.id, classId), eq(classes.teacherEmail, me.email)))
        .limit(1);
      if (!c) return fail("Không có quyền với lớp", 403);

      const jsonData = b.jsonData as Record<string, unknown> | undefined;
      if (!jsonData) return fail("Thiếu dữ liệu JSON");

      const { publicQuestions, answerKey, skipped, total } =
        buildExamFromV15(jsonData);
      if (!publicQuestions.length)
        return fail("File JSON không chứa câu hỏi hợp lệ nào.");

      const scoring = normalizeScoring(b.scoring ?? jsonData.scoring);
      const title = clean(b.title || "Kiểm tra Toán 12", 100);

      for (let i = 0; i < 5; i++) {
        const code = makeCode();
        const [dup] = await db.select().from(exams).where(eq(exams.code, code)).limit(1);
        if (dup) continue;
        await db.insert(exams).values({
          classId,
          teacherEmail: me.email,
          title,
          code,
          durationMinutes: Math.max(5, Math.min(180, Number(b.duration) || 45)),
          publicQuestions: JSON.stringify(publicQuestions),
          answerKey: JSON.stringify(answerKey),
          scoring: JSON.stringify(scoring),
          status: b.status === "draft" ? "draft" : "open",
          createdAt: now(),
        });
        await log(me.email, "importExam", "exam", code, {
          title,
          count: publicQuestions.length,
          skipped: skipped.length,
        });
        return Response.json({
          ok: true,
          code,
          count: publicQuestions.length,
          total,
          skipped,
        });
      }
      return fail("Không sinh được mã đề, thử lại.", 500);
    }

    /* ---------------- GIÁO VIÊN: mở / đóng đề ---------------- */
    if (action === "setExamStatus") {
      if (me.role !== "teacher") return fail("Không đủ quyền", 403);
      const examId = Number(b.examId);
      const status = b.status === "open" ? "open" : b.status === "draft" ? "draft" : "closed";
      const [ex] = await db
        .select()
        .from(exams)
        .where(and(eq(exams.id, examId), eq(exams.teacherEmail, me.email)))
        .limit(1);
      if (!ex) return fail("Không tìm thấy bài hoặc không có quyền", 403);
      await db.update(exams).set({ status }).where(eq(exams.id, examId));
      await log(me.email, "setExamStatus", "exam", examId, { status });
      return Response.json({ ok: true });
    }

    /* ---------------- GIÁO VIÊN: xoá đề ---------------- */
    if (action === "deleteExam") {
      if (me.role !== "teacher") return fail("Không đủ quyền", 403);
      const examId = Number(b.examId);
      const [ex] = await db
        .select()
        .from(exams)
        .where(and(eq(exams.id, examId), eq(exams.teacherEmail, me.email)))
        .limit(1);
      if (!ex) return fail("Không tìm thấy bài kiểm tra hoặc không có quyền", 403);

      const done = await db.select().from(attempts).where(eq(attempts.examId, examId));
      // Chống xoá nhầm: đã có bài nộp thì phải xác nhận lần hai.
      if (done.length && b.confirmDeleteAttempts !== true)
        return fail(
          `Bài này đã có ${done.length} lượt nộp. Hãy dùng "Đóng bài" thay vì xoá, hoặc xác nhận xoá cả kết quả.`,
          409
        );

      await db.delete(attempts).where(eq(attempts.examId, examId));
      await db.delete(examStarts).where(eq(examStarts.examId, examId));
      await db.delete(exams).where(eq(exams.id, examId));
      await log(me.email, "deleteExam", "exam", examId, {
        title: ex.title,
        removedAttempts: done.length,
      });
      return Response.json({ ok: true });
    }

    /* ---------------- HỌC SINH: bắt đầu làm bài ----------------
       Thời điểm bắt đầu do MÁY CHỦ ghi, ghi một lần duy nhất.       */
    if (action === "startExam") {
      if (me.role !== "student") return fail("Không đủ quyền", 403);
      const examId = Number(b.examId);
      const [e] = await db
        .select()
        .from(exams)
        .where(and(eq(exams.id, examId), eq(exams.status, "open")))
        .limit(1);
      if (!e) return fail("Bài không còn mở", 404);

      const [m] = await db
        .select()
        .from(memberships)
        .where(
          and(eq(memberships.classId, e.classId), eq(memberships.studentEmail, me.email))
        )
        .limit(1);
      if (!m) return fail("Em chưa thuộc lớp này", 403);

      const [existingAttempt] = await db
        .select()
        .from(attempts)
        .where(and(eq(attempts.examId, examId), eq(attempts.studentEmail, me.email)))
        .limit(1);
      if (existingAttempt) return fail("Em đã nộp bài này rồi.", 409);

      await db
        .insert(examStarts)
        .values({ examId, studentEmail: me.email, startedAt: now() })
        .onConflictDoNothing();

      const [st] = await db
        .select()
        .from(examStarts)
        .where(and(eq(examStarts.examId, examId), eq(examStarts.studentEmail, me.email)))
        .limit(1);

      const startedAt = st?.startedAt ?? now();
      const deadline = new Date(
        new Date(startedAt).getTime() + e.durationMinutes * 60_000
      ).toISOString();
      await log(me.email, "startExam", "exam", examId, { startedAt });
      return Response.json({ ok: true, startedAt, deadline });
    }

    /* ---------------- HỌC SINH: nộp bài ---------------- */
    if (action === "submitExam") {
      if (me.role !== "student") return fail("Không đủ quyền", 403);
      const examId = Number(b.examId);

      const [e] = await db
        .select()
        .from(exams)
        .where(and(eq(exams.id, examId), eq(exams.status, "open")))
        .limit(1);
      if (!e) return fail("Bài không còn mở", 404);

      const [m] = await db
        .select()
        .from(memberships)
        .where(
          and(eq(memberships.classId, e.classId), eq(memberships.studentEmail, me.email))
        )
        .limit(1);
      if (!m) return fail("Em chưa thuộc lớp này", 403);

      /* ❗ CHẶN LỖ HỔNG DÒ ĐÁP ÁN:
         bản cũ luôn chấm và trả điểm kể cả khi không ghi được bản ghi,
         nên học sinh gọi API lặp lại là dò ra đáp án. Nay kiểm tra TRƯỚC. */
      const [old] = await db
        .select()
        .from(attempts)
        .where(and(eq(attempts.examId, examId), eq(attempts.studentEmail, me.email)))
        .limit(1);
      if (old)
        return fail("Em đã nộp bài này rồi. Mỗi bài chỉ được nộp một lần.", 409);

      /* Thời gian: lấy từ examStarts, không tin startedAt do client gửi. */
      const [st] = await db
        .select()
        .from(examStarts)
        .where(and(eq(examStarts.examId, examId), eq(examStarts.studentEmail, me.email)))
        .limit(1);
      if (!st) return fail("Em chưa bấm Bắt đầu làm bài.", 409);

      const elapsed = (Date.now() - new Date(st.startedAt).getTime()) / 1000;
      if (elapsed > e.durationMinutes * 60 + SUBMIT_GRACE_SECONDS)
        return fail("Đã quá thời gian làm bài, hệ thống không nhận bài nộp.", 409);

      const answers = (b.answers && typeof b.answers === "object"
        ? b.answers
        : {}) as Record<string, unknown>;

      const key = normalizeAnswerKey(safeParse(e.answerKey, {}));
      const sc = normalizeScoring(safeParse(e.scoring, DEFAULT_SCORING));
      const r = gradeAll(key, answers, sc);

      await db.insert(attempts).values({
        examId,
        studentEmail: me.email,
        studentName: me.name,
        answers: JSON.stringify(answers).slice(0, 100_000),
        score: r.correctCount,
        maxScore: r.total,
        points: r.points,
        maxPoints: r.maxPoints,
        startedAt: st.startedAt,
        submittedAt: now(),
      });

      await log(me.email, "submitExam", "exam", examId, {
        points: r.points,
        maxPoints: r.maxPoints,
      });

      return Response.json({
        ok: true,
        points: r.points,
        maxPoints: r.maxPoints,
        correctCount: r.correctCount,
        total: r.total,
        display: displayScore(r.points, r.maxPoints, sc.scale10),
        scale10: sc.scale10,
      });
    }

    return fail("Không đủ quyền hoặc thao tác không hợp lệ", 403);
  } catch (e) {
    return Response.json(
      { error: e instanceof Error ? e.message : "Lỗi máy chủ" },
      { status: 500 }
    );
  }
}
