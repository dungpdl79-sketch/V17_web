# Bản vá V17 — hướng dẫn áp dụng

## 1. Chép file vào dự án

Giải nén và chép đè theo đúng cây thư mục (đường dẫn tính từ thư mục `V17_WEB/`):

| Chép vào | Việc |
|---|---|
| `lib/config.ts` | **mới** — thầy phải sửa nội dung |
| `lib/auth.ts` | mới |
| `lib/grading.ts` | mới |
| `lib/import-v15.ts` | mới |
| `lib/sanitize-client.ts` | mới |
| `db/schema.ts` | **đè** file cũ |
| `drizzle/0001_v17_security.sql` | mới |
| `app/page.tsx` | **đè** |
| `app/layout.tsx` | **đè** |
| `app/v17-dashboard.tsx` | **đè** |
| `app/api/v17/route.ts` | **đè** |
| `app/api/auth/route.ts` | mới |
| `app/components/*.tsx`, `types.ts` | mới (7 file) |
| `vite.config.ts` | **đè** |
| `wrangler.toml` | **đè** |
| `app/globals-additions.css` | **dán nội dung vào cuối** `app/globals.css` (đừng đè file) |

Có thể xoá `app/chatgpt-auth.ts` — không còn dùng.

## 2. Sửa cấu hình bắt buộc

Mở `lib/config.ts`:

```ts
export const TEACHER_EMAILS = ["email-that-cua-thay@..."];
export const TEACHER_SIGNUP_CODE = "…đổi mã này…";
export const LEGACY_ACTIVATION_CODE = "…đổi mã này…";
```

* Email nằm trong `TEACHER_EMAILS` → đăng ký ra vai trò **giáo viên**, nhưng phải nhập đúng `TEACHER_SIGNUP_CODE`.
* Mọi email khác → **học sinh**.
* Tài khoản đã có sẵn trong CSDL từ bản cũ (chưa có mật khẩu) cần `LEGACY_ACTIVATION_CODE` để đặt mật khẩu lần đầu.

## 3. Cập nhật CSDL

```bash
# thử ở máy trước
npx wrangler d1 execute dinhcaotritue-db --local --file=drizzle/0001_v17_security.sql
# rồi mới chạy thật
npx wrangler d1 execute dinhcaotritue-db --remote --file=drizzle/0001_v17_security.sql
```

Script này còn **đóng tất cả đề đang mở**, vì đề phát bằng bản cũ có thể đang chứa đáp án Đúng/Sai trong dữ liệu gửi xuống học sinh. Sau khi vá, thầy nạp lại đề từ file JSON của V15 rồi phát mới.

## 4. Chạy thử

```bash
npm run dev      # http://localhost:5173
npm run build
```

Kịch bản kiểm thử tối thiểu:

1. Đăng ký tài khoản giáo viên → tạo lớp → lấy mã lớp.
2. Mở cửa sổ ẩn danh, đăng ký một tài khoản học sinh → vào lớp bằng mã.
3. Giáo viên: Studio đề → chọn lớp, đặt thang điểm → nạp `NganHangCauHoi_2026-08-22.json` → phát bài.
4. Học sinh: bấm **Bắt đầu làm bài** → kiểm tra công thức toán đã hiện đẹp, câu Đúng/Sai có đủ 4 ý → nộp.
5. Mở DevTools → Network → xem phản hồi `/api/v17`: **không được thấy** trường `ans` ở bất kỳ đâu.
6. Nộp lại lần hai → phải nhận lỗi 409.
7. Bấm nút ⏻ → phải quay về màn hình đăng nhập.

## 5. Những gì bản vá đã sửa

| # | Lỗi cũ | Cách sửa |
|---|---|---|
| 1 | Cookie `user_session` là JSON thô, gõ email ai cũng thành người đó | Mật khẩu PBKDF2-SHA256 150k vòng + phiên lưu ở CSDL, cookie chỉ chứa token ngẫu nhiên, `HttpOnly`, hết hạn 7 ngày |
| 2 | `setRole` cho phép tự phong giáo viên | Vai trò do máy chủ gán theo `TEACHER_EMAILS` + mã giáo viên |
| 3 | Đáp án Đúng/Sai lọt xuống máy học sinh trong `stmts` | `buildExamFromV15` chỉ đẩy `{t}`; `stripAnswers` lọc lần hai lúc đọc |
| 4 | Câu Đúng/Sai không được chấm (`undefined` bị `JSON.stringify` bỏ) | `answerKey` đổi sang `{type, ans}`, có `normalizeAnswerKey` đọc được cả dữ liệu cũ |
| 5 | Câu Đúng/Sai hiện thành một ô text | Bảng 4 ý Đúng/Sai trong `exam-player.tsx` |
| 6 | Nộp lại nhiều lần vẫn được chấm ⇒ dò được đáp án | Kiểm tra `attempts` **trước** khi chấm, trả 409 |
| 7 | Không hiển thị được `$…$` | Nạp MathJax trong `layout.tsx`, gọi `typesetPromise` sau mỗi lần render |
| 8 | Mỗi câu 1 điểm, mất thang điểm V15 | `lib/grading.ts` + cột `exams.scoring`, có ô nhập thang điểm trong Studio |
| 9 | `durationMinutes` chỉ để trưng bày, `startedAt` do client khai | Bảng `exam_starts`, đồng hồ đếm ngược, tự nộp, máy chủ từ chối bài quá giờ |
| 10 | `audit_logs` chưa từng được ghi | Ghi thật cho đăng nhập, tạo lớp, phát đề, bắt đầu, nộp bài, xoá bài |
| 11 | Nút đăng xuất trỏ vào `/signout-with-chatgpt` | `POST /api/auth {mode:"logout"}` xoá phiên + xoá cookie |
| 12 | `vite.config` đặt binding `dinhcaotritue_db` nhưng code đọc `env.DB` | Dùng chung tên `DB` |
| 13 | `wrangler.toml` trỏ `./dist/index.js` | Sửa thành `./dist/server/index.js` |
| 14 | `makeCode()` dùng `Math.random`, trùng mã là lỗi 500 | `crypto.getRandomValues` + thử lại 5 lần |
| 15 | Xoá đề là mất luôn bài nộp, không cảnh báo | Có nút **Đóng bài**; xoá khi đã có bài nộp phải xác nhận hai lần |
| 16 | Không sửa được trạng thái đề | Thêm `setExamStatus` (mở / đóng) |
| 17 | Bảng kết quả hiện `#examId` | Hiện tên bài + mã bài; CSV đủ cột |
| 18 | `window.print()` in cả sidebar | Thêm `@media print` |
| 19 | `key={o}` theo nội dung phương án | Đổi sang `${q.id}-${j}` |
| 20 | Radio không có `checked`, mất lựa chọn khi re-render | Điều khiển hoàn toàn bằng state |
| 21 | `data.user.name[0]` crash khi tên rỗng | Có giá trị dự phòng |
| 22 | Dashboard 13 KB trong một dòng | Tách thành 7 file có kiểu dữ liệu rõ ràng |
| 23 | Truy vấn D1 tuần tự | Gom bằng `Promise.all` |
| 24 | `URL.createObjectURL` không thu hồi khi xuất CSV | Thêm `revokeObjectURL` |

## 6. Việc còn lại (chưa nằm trong bản vá)

* **MathJax vẫn tải từ CDN.** Nên tải `tex-mml-chtml.js` về `public/mathjax/` để phòng máy trường mất mạng vẫn dùng được — hướng dẫn nằm trong comment ở `app/layout.tsx`.
* Chưa có màn hình cho giáo viên **xem chi tiết bài làm** của từng học sinh.
* Chưa có **xoá lớp**, **đổi tên lớp**, **xoá học sinh khỏi lớp**.
* Chưa có **quên mật khẩu** — hiện phải sửa trực tiếp trong D1.
* Chưa có **giới hạn tần suất** cho `/api/auth`; nếu mở ra Internet nên thêm Cloudflare Turnstile hoặc Rate Limiting.
* V15 và V17 vẫn là hai ngân hàng câu hỏi tách rời. Bước hợp nhất tiếp theo là đưa ngân hàng câu hỏi lên D1 để cả tổ dùng chung.
