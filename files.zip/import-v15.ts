/* ============================================================================
   Nạp JSON từ Đỉnh Cao Trí Tuệ V15 và TÁCH ĐÔI:
     - publicQuestions : phần gửi xuống máy học sinh — TUYỆT ĐỐI không chứa
                         đáp án, lời giải, phản hồi lỗi.
     - answerKey       : phần chỉ nằm ở máy chủ.
   Đây là chỗ sửa lỗi rò đáp án Đúng/Sai của bản cũ.
   ========================================================================== */

import type { KeyItem } from "@/lib/grading";

export type PublicQuestion =
  | { id: string; type: "mcq"; q: string; opts: string[] }
  | { id: string; type: "tf"; q: string; stmts: { t: string }[] }
  | { id: string; type: "sa"; q: string };

const MAX_QUESTIONS = 200;
const MAX_LEN = 20_000;

const str = (v: unknown, max = MAX_LEN) => String(v ?? "").slice(0, max);

type RawQ = Record<string, unknown>;

function detectType(q: RawQ): "mcq" | "tf" | "sa" {
  if (Array.isArray(q.stmts)) return "tf";
  if (Array.isArray(q.opts) && q.opts.length) return "mcq";
  return "sa";
}

export function buildExamFromV15(jsonData: Record<string, unknown>) {
  const mcq = Array.isArray(jsonData.mcq) ? (jsonData.mcq as RawQ[]) : [];
  const tf = Array.isArray(jsonData.tf) ? (jsonData.tf as RawQ[]) : [];
  const sa = Array.isArray(jsonData.sa) ? (jsonData.sa as RawQ[]) : [];

  const all = [...mcq, ...tf, ...sa].slice(0, MAX_QUESTIONS);

  const publicQuestions: PublicQuestion[] = [];
  const answerKey: Record<string, KeyItem> = {};
  const skipped: string[] = [];

  all.forEach((q, i) => {
    const id = `q${i + 1}`;
    const type = detectType(q);
    const stem = str(q.q) || `Câu ${i + 1}`;

    if (type === "mcq") {
      const opts = (q.opts as unknown[]).map((o) => str(o)).slice(0, 10);
      const ans = Number(q.ans);
      if (!opts.length || !Number.isInteger(ans) || ans < 0 || ans >= opts.length) {
        skipped.push(`${id} (trắc nghiệm: đáp án không hợp lệ)`);
        return;
      }
      publicQuestions.push({ id, type: "mcq", q: stem, opts });
      answerKey[id] = { type: "mcq", ans };
      return;
    }

    if (type === "tf") {
      const raw = (q.stmts as unknown[]).slice(0, 4) as RawQ[];
      const stmts = raw
        .filter((s) => s && typeof s === "object")
        .map((s) => ({ t: str(s.t) }));
      const ans = raw.map((s) => Boolean(s?.ans));
      if (!stmts.length) {
        skipped.push(`${id} (đúng/sai: không có ý nào)`);
        return;
      }
      // ⚠️ CHỈ đẩy { t } — trường ans ở lại máy chủ.
      publicQuestions.push({ id, type: "tf", q: stem, stmts });
      answerKey[id] = { type: "tf", ans };
      return;
    }

    const ans = str(q.ans, 200).trim();
    if (!ans) {
      skipped.push(`${id} (trả lời ngắn: thiếu đáp án)`);
      return;
    }
    publicQuestions.push({ id, type: "sa", q: stem });
    answerKey[id] = { type: "sa", ans };
  });

  return { publicQuestions, answerKey, skipped, total: all.length };
}

/* ---------------------------------------------------------------------------
   Lớp phòng thủ thứ hai: đề CŨ trong CSDL có thể còn chứa đáp án trong stmts.
   Luôn chạy hàm này trước khi trả publicQuestions ra ngoài.
   ------------------------------------------------------------------------- */
export function stripAnswers(questions: unknown): PublicQuestion[] {
  if (!Array.isArray(questions)) return [];
  return questions.map((raw, i) => {
    const q = (raw ?? {}) as RawQ;
    const id = str(q.id, 40) || `q${i + 1}`;
    const stem = str(q.q);
    if (Array.isArray(q.stmts) && q.stmts.length) {
      return {
        id,
        type: "tf" as const,
        q: stem,
        stmts: (q.stmts as RawQ[]).map((s) => ({ t: str(s?.t) })),
      };
    }
    if (Array.isArray(q.opts) && q.opts.length) {
      return {
        id,
        type: "mcq" as const,
        q: stem,
        opts: (q.opts as unknown[]).map((o) => str(o)),
      };
    }
    return { id, type: "sa" as const, q: stem };
  });
}
