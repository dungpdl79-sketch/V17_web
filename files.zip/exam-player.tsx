"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import SafeHtml from "./safe-html";
import type { ExamAnswers, ExamRow } from "./types";

function fmt(sec: number) {
  const s = Math.max(0, Math.floor(sec));
  return `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
}

export default function ExamPlayer({
  exam,
  startedAt,
  onStart,
  onSubmit,
  busy,
}: {
  exam: ExamRow;
  /** Do MÁY CHỦ cấp; null nghĩa là chưa bắt đầu. */
  startedAt: string | null;
  onStart: () => Promise<void>;
  onSubmit: (answers: ExamAnswers) => Promise<void>;
  busy: boolean;
}) {
  const [answers, setAnswers] = useState<ExamAnswers>({});
  const [left, setLeft] = useState<number | null>(null);
  const submittedRef = useRef(false);
  const answersRef = useRef(answers);
  answersRef.current = answers;

  const doSubmit = useCallback(async () => {
    if (submittedRef.current) return;
    submittedRef.current = true;
    await onSubmit(answersRef.current);
  }, [onSubmit]);

  /* Đếm ngược theo mốc thời gian của máy chủ; hết giờ thì tự nộp. */
  useEffect(() => {
    if (!startedAt) return;
    const deadline =
      new Date(startedAt).getTime() + exam.durationMinutes * 60_000;
    const tick = () => {
      const remain = (deadline - Date.now()) / 1000;
      setLeft(remain);
      if (remain <= 0) doSubmit();
    };
    tick();
    const t = setInterval(tick, 1000);
    return () => clearInterval(t);
  }, [startedAt, exam.durationMinutes, doSubmit]);

  if (!startedAt) {
    return (
      <div className="exam-start">
        <p>
          {exam.publicQuestions.length} câu · {exam.durationMinutes} phút.
          Đồng hồ bắt đầu chạy ngay khi em bấm nút và <b>không thể tạm dừng</b>.
        </p>
        <button className="primary-btn" disabled={busy} onClick={onStart}>
          ▶ Bắt đầu làm bài
        </button>
      </div>
    );
  }

  const setMcq = (qid: string, v: string) =>
    setAnswers((a) => ({ ...a, [qid]: v }));

  const setTf = (qid: string, i: number, v: "T" | "F") =>
    setAnswers((a) => {
      const cur = Array.isArray(a[qid]) ? [...(a[qid] as string[])] : [];
      cur[i] = cur[i] === v ? "" : v; // bấm lại để bỏ chọn
      return { ...a, [qid]: cur };
    });

  const answered = exam.publicQuestions.filter((q) => {
    const v = answers[q.id];
    return Array.isArray(v) ? v.some(Boolean) : Boolean(v);
  }).length;

  const low = left !== null && left < 300;

  return (
    <div className="exam-run">
      <div className={low ? "exam-bar low" : "exam-bar"}>
        <span>⏱ {left === null ? "--:--" : fmt(left)}</span>
        <span>
          Đã làm {answered}/{exam.publicQuestions.length}
        </span>
      </div>

      {exam.publicQuestions.map((q, i) => (
        <div className="student-q" key={q.id}>
          <div className="q-head">
            <b>Câu {i + 1}.</b>
            <SafeHtml html={q.q} className="q-body" />
          </div>

          {q.type === "mcq" && (
            <div className="opt-list">
              {q.opts.map((o, j) => (
                <label key={`${q.id}-${j}`} className="opt">
                  <input
                    type="radio"
                    name={`${exam.id}-${q.id}`}
                    value={String(j)}
                    checked={answers[q.id] === String(j)}
                    onChange={() => setMcq(q.id, String(j))}
                  />
                  <span className="opt-letter">
                    {String.fromCharCode(65 + j)}.
                  </span>
                  <SafeHtml html={o} className="opt-body" />
                </label>
              ))}
            </div>
          )}

          {/* ❗ Bản cũ render câu Đúng/Sai thành một ô text. Nay đủ 4 ý. */}
          {q.type === "tf" && (
            <table className="tf-table">
              <thead>
                <tr>
                  <th></th>
                  <th>Nội dung</th>
                  <th>Đúng</th>
                  <th>Sai</th>
                </tr>
              </thead>
              <tbody>
                {q.stmts.map((s, j) => {
                  const cur = (answers[q.id] as string[] | undefined)?.[j] ?? "";
                  return (
                    <tr key={`${q.id}-s${j}`}>
                      <td className="tf-letter">
                        {String.fromCharCode(97 + j)})
                      </td>
                      <td>
                        <SafeHtml html={s.t} />
                      </td>
                      <td>
                        <input
                          type="radio"
                          name={`${exam.id}-${q.id}-${j}`}
                          checked={cur === "T"}
                          onChange={() => setTf(q.id, j, "T")}
                        />
                      </td>
                      <td>
                        <input
                          type="radio"
                          name={`${exam.id}-${q.id}-${j}`}
                          checked={cur === "F"}
                          onChange={() => setTf(q.id, j, "F")}
                        />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}

          {q.type === "sa" && (
            <input
              className="sa-input"
              type="text"
              inputMode="text"
              placeholder="Nhập đáp án"
              value={(answers[q.id] as string) ?? ""}
              onChange={(e) => setMcq(q.id, e.target.value)}
            />
          )}
        </div>
      ))}

      <button
        className="primary-btn"
        disabled={busy}
        onClick={() => {
          if (
            answered < exam.publicQuestions.length &&
            !confirm(
              `Em còn ${exam.publicQuestions.length - answered} câu chưa làm. Vẫn nộp bài?`
            )
          )
            return;
          doSubmit();
        }}
      >
        Nộp bài
      </button>
    </div>
  );
}
