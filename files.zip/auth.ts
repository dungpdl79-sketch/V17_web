import { and, eq, gt, lt } from "drizzle-orm";
import { getDb } from "@/db";
import { sessions, users } from "@/db/schema";
import { SESSION_TTL_SECONDS } from "@/lib/config";

export const SESSION_COOKIE = "v17_session";
const PBKDF2_ITERATIONS = 150_000;
const enc = new TextEncoder();

const toHex = (buf: ArrayBuffer) =>
  [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");

export function randomHex(bytes = 32) {
  const a = new Uint8Array(bytes);
  crypto.getRandomValues(a);
  return toHex(a.buffer);
}

export async function sha256Hex(s: string) {
  return toHex(await crypto.subtle.digest("SHA-256", enc.encode(s)));
}

/* ---------------- Mật khẩu: PBKDF2-SHA256, có muối riêng từng tài khoản ---- */

export async function hashPassword(password: string, salt = randomHex(16)) {
  const key = await crypto.subtle.importKey(
    "raw",
    enc.encode(password),
    "PBKDF2",
    false,
    ["deriveBits"]
  );
  const bits = await crypto.subtle.deriveBits(
    {
      name: "PBKDF2",
      salt: enc.encode(salt),
      iterations: PBKDF2_ITERATIONS,
      hash: "SHA-256",
    },
    key,
    256
  );
  return { salt, hash: toHex(bits) };
}

/** So sánh trong thời gian hằng số để không lộ thông tin qua thời gian phản hồi. */
function safeEqual(a: string, b: string) {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

export async function verifyPassword(
  password: string,
  salt: string | null,
  expected: string | null
) {
  if (!salt || !expected) return false;
  const { hash } = await hashPassword(password, salt);
  return safeEqual(hash, expected);
}

/* ---------------- Phiên đăng nhập lưu ở máy chủ ---------------------------- */

export async function createSession(email: string) {
  const db = getDb();
  const token = randomHex(32);
  const id = await sha256Hex(token);
  const now = new Date();
  const exp = new Date(now.getTime() + SESSION_TTL_SECONDS * 1000);

  // Dọn phiên hết hạn (rẻ, chạy kèm mỗi lần đăng nhập).
  await db.delete(sessions).where(lt(sessions.expiresAt, now.toISOString()));
  await db.insert(sessions).values({
    id,
    email: email.toLowerCase(),
    createdAt: now.toISOString(),
    expiresAt: exp.toISOString(),
  });
  return { token, expiresAt: exp };
}

export async function destroySession(token: string | null) {
  if (!token) return;
  const db = getDb();
  await db.delete(sessions).where(eq(sessions.id, await sha256Hex(token)));
}

export function readTokenFromCookieHeader(header: string | null) {
  if (!header) return null;
  const m = header.match(new RegExp(`(?:^|;\\s*)${SESSION_COOKIE}=([^;]+)`));
  return m ? decodeURIComponent(m[1]) : null;
}

export type AuthUser = {
  email: string;
  name: string;
  role: "teacher" | "student";
};

/** Trả về hồ sơ người dùng nếu token hợp lệ và chưa hết hạn. */
export async function getUserByToken(
  token: string | null
): Promise<AuthUser | null> {
  if (!token || !/^[a-f0-9]{64}$/.test(token)) return null;
  const db = getDb();
  const id = await sha256Hex(token);
  const [s] = await db
    .select()
    .from(sessions)
    .where(and(eq(sessions.id, id), gt(sessions.expiresAt, new Date().toISOString())))
    .limit(1);
  if (!s) return null;

  const [u] = await db.select().from(users).where(eq(users.email, s.email)).limit(1);
  if (!u) return null;
  return { email: u.email, name: u.name, role: u.role };
}

/* ---------------- Cookie ---------------------------------------------------- */

const isProd = process.env.NODE_ENV !== "development";

export function sessionCookieHeader(token: string) {
  return [
    `${SESSION_COOKIE}=${token}`,
    "Path=/",
    "HttpOnly",
    "SameSite=Lax",
    isProd ? "Secure" : "",
    `Max-Age=${SESSION_TTL_SECONDS}`,
  ]
    .filter(Boolean)
    .join("; ");
}

export const clearCookieHeader = [
  `${SESSION_COOKIE}=`,
  "Path=/",
  "HttpOnly",
  "SameSite=Lax",
  isProd ? "Secure" : "",
  "Max-Age=0",
]
  .filter(Boolean)
  .join("; ");
